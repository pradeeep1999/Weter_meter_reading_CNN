import cv2
from ultralytics import YOLO
import os

def crop_and_save_meter(input_image_path, output_folder):
    """
    Detects a water meter odometer from a real-world image, 
    crops it, and saves the result.
    """
    
    # 1. Load a pre-trained model (YOLOv8n is Nano, great for speed)
    # You will use your own fine-tuned model here eventually.
    # For now, we will use a general model to demonstrate the cropping.
    model = YOLO('yolov8n.pt') 

    # 2. Run Inference on the source image
    results = model.predict(input_image_path, conf=0.5) # 0.5 confidence threshold

    # 3. Process the results (we assume one primary detection)
    if not results[0].boxes:
        print(f"No object detected in: {input_image_path}")
        return

    # Extract the first bounding box (best detection)
    box = results[0].boxes[0]
    x1, y1, x2, y2 = map(int, box.xyxy[0])  # Convert to integer coordinates

    # 4. Read the original image with OpenCV
    original_image = cv2.imread(input_image_path)
    if original_image is None:
        print(f"Failed to load image: {input_image_path}")
        return

    # 5. Crop the Image [y1:y2, x1:x2]
    cropped_meter = original_image[y1:y2, x1:x2]

    # 6. Create the output folder if it doesn't exist
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 7. Generate a unique filename and save the crop
    base_name = os.path.basename(input_image_path)
    filename, ext = os.path.splitext(base_name)
    save_path = os.path.join(output_folder, f"{filename}_meter_crop{ext}")
    
    cv2.imwrite(save_path, cropped_meter)
    print(f"Cropped meter saved to: {save_path}")

# --- Example Usage ---
# Use the full meter image you have
source_image = r'D:\Projects\12.STM32_Water reader\04.Real_word_images_by_phone\20260227_150136.jpg' 
# The folder to save the cropped results
destination_folder = r'D:/Projects/13.Picture_/03.Picture_for_yolo/2/crops/' 

if __name__ == '__main__':
    # Make sure the source file exists before running
    if os.path.exists(source_image):
        crop_and_save_meter(source_image, destination_folder)
    else:
        print(f"File not found: {source_image}")