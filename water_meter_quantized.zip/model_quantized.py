import tensorflow as tf
import numpy as np
import os
from pathlib import Path

# Paths
MODEL_PATH = 'water_meter_final_40x40_rgb.h5'
TFLITE_PATH = 'water_meter_quantized_40x40.tflite'
# Use the TXT dataset for calibration
DATA_PATH = Path(r"D:\Projects\12.STM32_Water reader\06.Resized_Dataset_40x40_txt")

# 1. Load the Keras model
model = tf.keras.models.load_model(MODEL_PATH)

# 2. Representative Dataset Generator (from .txt files)
def representative_data_gen():
    class_names = ['0','1','2','3','4','5','6','7','8','9']
    count = 0
    max_samples = 100  # Calibration usually needs 100-200 samples
    
    for class_name in class_names:
        class_folder = DATA_PATH / class_name
        if not class_folder.exists():
            continue
            
        for txt_file in class_folder.glob("*.txt"):
            if count >= max_samples:
                return
            
            # Load and reshape to (1, 40, 40, 3)
            data = np.loadtxt(txt_file, dtype=np.float32)
            img = data.reshape((1, 40, 40, 3)) 
            
            # Note: Your model HAS a Rescaling(1./255) layer inside, 
            # so we pass raw pixel values (0.0 to 255.0)
            yield [img]
            count += 1

# 3. Converter Setup
converter = tf.lite.TFLiteConverter.from_keras_model(model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]
converter.representative_dataset = representative_data_gen

# 4. Enforce Full Integer Quantization (Required for STM32 / X-CUBE-AI)
converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
converter.inference_input_type = tf.int8
converter.inference_output_type = tf.int8

# Important for newer TF versions to ensure compatibility with MCU
converter.target_spec.supported_types = [tf.int8]

tflite_model = converter.convert()

# 5. Save the TFLite model
with open(TFLITE_PATH, 'wb') as f:
    f.write(tflite_model)

print(f"✅ Quantized model saved to: {TFLITE_PATH}")
print(f"   Input shape: (1, 40, 40, 3)")
print(f"   Format: Full Integer (INT8)")