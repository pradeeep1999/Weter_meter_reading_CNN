import tensorflow as tf
import numpy as np
import cv2

# 1. Load Model
model = tf.keras.models.load_model("water_meter_best.h5")

# 2. Image Path
img_path = r"D:\Projects\12.STM32_Water reader\123\test7_1.png"

# 3. Load and Pre-process
# We load as grayscale and resize to 28x28
img = tf.keras.preprocessing.image.load_img(
    img_path, 
    target_size=(28, 28), 
    color_mode="grayscale"
)

# Convert to array
img_array = tf.keras.preprocessing.image.img_to_array(img)

# IMPORTANT: No 255-image here, because we want to keep the black background
# The model's internal Rescaling(1./255) layer will handle normalization.

# 4. Add Batch Dimension
img_array = np.expand_dims(img_array, axis=0)

# 5. Predict
predictions = model.predict(img_array)
predicted_class = np.argmax(predictions[0])
confidence = np.max(predictions[0])

class_names = ['0','1','2','3','4','5','6','7','8','9']

print(f"\n--- Result ---")
print(f"Predicted Digit: {class_names[predicted_class]}")
print(f"Confidence: {100 * confidence:.2f}%")