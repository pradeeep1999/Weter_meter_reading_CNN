import os
from datetime import datetime

# Set your directory path
directory = r'D:\Projects\13.Picture_\black_9\9'

def rename_files_with_date(folder_path):
    # Check if directory exists
    if not os.path.exists(folder_path):
        print("Directory not found.")
        return

    for filename in os.listdir(folder_path):
        # Process only .txt files
        if filename.endswith(".txt"):
            file_path = os.path.join(folder_path, filename)
            
            # Get the last modified timestamp
            timestamp = os.path.getmtime(file_path)
            # Convert to readable format (Year-Month-Day)
            date_prefix = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d_')
            
            # Create new name (e.g., 2026-05-11_frame_000000.txt)
            new_filename = date_prefix + filename
            new_file_path = os.path.join(folder_path, new_filename)
            
            # Rename the file
            try:
                os.rename(file_path, new_file_path)
                print(f"Renamed: {filename} -> {new_filename}")
            except Exception as e:
                print(f"Error renaming {filename}: {e}")

# Run the function
rename_files_with_date(directory)