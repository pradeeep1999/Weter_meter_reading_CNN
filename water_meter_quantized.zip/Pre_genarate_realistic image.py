import os
import cv2
import random
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# ---------------- CONFIG ----------------
DATA_PATH = "WaterMeter_80Percent_Prev"
IMG_SIZE = 28
COUNT_PER_DIGIT = 500

os.makedirs(DATA_PATH, exist_ok=True)

def generate_80percent_prev_digit(digit):
    # Background: Dark/Industrial gray
    bg_val = random.randint(10, 30)
    bg_color = (bg_val, bg_val, bg_val)

    # Text: Bright white/off-white
    txt_val = random.randint(230, 255)
    txt_color = (txt_val, txt_val, txt_val)

    # Create vertical stacked canvas
    canvas_height = IMG_SIZE * 3
    canvas = Image.new("RGB", (IMG_SIZE, canvas_height), bg_color)
    draw = ImageDraw.Draw(canvas)

    try:
        font = ImageFont.truetype("arialbd.ttf", 26)
    except:
        font = ImageFont.load_default()

    digits_list = [(digit - 1) % 10, digit, (digit + 1) % 10]

    for i, val in enumerate(digits_list):
        bbox = draw.textbbox((0, 0), str(val), font=font)
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]

        draw.text(
            ((IMG_SIZE - w) // 2, IMG_SIZE * i + (IMG_SIZE - h) // 2),
            str(val),
            font=font,
            fill=txt_color
        )

    img = np.array(canvas)

    # ---------------- CROP LOGIC ----------------
    # Random percentage between 44% and 65%
    shift_percent = random.uniform(0.30, 0.70)
    shift_pixels = int(shift_percent * IMG_SIZE)
    start_y = IMG_SIZE - shift_pixels
    img = img[start_y:start_y + IMG_SIZE, :]

    # ---------------- Realistic Effects ----------------
    if random.random() > 0.3:
        kernel_size = 3
        kernel_v = np.zeros((kernel_size, kernel_size))
        kernel_v[:, int((kernel_size - 1)/2)] = np.ones(kernel_size)
        kernel_v /= kernel_size
        img = cv2.filter2D(img, -1, kernel_v)

    img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    noise = np.random.randint(0, 10, (IMG_SIZE, IMG_SIZE), dtype='uint8')
    img = cv2.add(img, noise)

    alpha = random.uniform(0.9, 1.1)
    beta = random.randint(-5, 5)
    img = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)

    return img


# ---------------- DATASET GENERATION ----------------
print(f"Generating dataset at: {DATA_PATH}...")

for d in range(10):
    folder = os.path.join(DATA_PATH, str(d))
    os.makedirs(folder, exist_ok=True)

    for i in range(COUNT_PER_DIGIT):
        sample = generate_80percent_prev_digit(d)
        filename = f"P_digit_{d}_sample_{i:04d}.png"
        cv2.imwrite(os.path.join(folder, filename), sample)

    print(f"Completed Digit {d}: {COUNT_PER_DIGIT} samples")

print("\nDone! Dataset ready.")