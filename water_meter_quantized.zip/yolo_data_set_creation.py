import cv2
import os

# =========================
# PATHS
# =========================
input_folder = r"D:\Projects\14.Object_detection\04.Real_word_images_by_phone\resized_640"
output_folder = r"D:\Projects\14.Object_detection\create_folder"

images_out = os.path.join(output_folder, "images")
labels_out = os.path.join(output_folder, "labels")

os.makedirs(images_out, exist_ok=True)
os.makedirs(labels_out, exist_ok=True)

# =========================
# GET IMAGES
# =========================
images = sorted([f for f in os.listdir(input_folder) if f.endswith((".jpg", ".png", ".jpeg"))])

# =========================
# GLOBAL VARIABLES
# =========================
drawing = False
ix, iy = -1, -1
boxes = []

current_image = None
clone = None
img_name = ""
img_index = 1

# =========================
# MOUSE CALLBACK
# =========================
def draw_box(event, x, y, flags, param):
    global ix, iy, drawing, current_image, clone, boxes

    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        ix, iy = x, y

    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing:
            temp = clone.copy()
            cv2.rectangle(temp, (ix, iy), (x, y), (0, 255, 0), 2)
            cv2.imshow("Annotate", temp)

    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        cv2.rectangle(clone, (ix, iy), (x, y), (0, 255, 0), 2)
        boxes.append((ix, iy, x, y))
        cv2.imshow("Annotate", clone)

# =========================
# YOLO FORMAT CONVERTER
# =========================
def convert_yolo(x1, y1, x2, y2, w, h):
    x_center = (x1 + x2) / 2 / w
    y_center = (y1 + y2) / 2 / h
    bw = abs(x2 - x1) / w
    bh = abs(y2 - y1) / h
    return x_center, y_center, bw, bh

# =========================
# MAIN LOOP
# =========================
cv2.namedWindow("Annotate")
cv2.setMouseCallback("Annotate", draw_box)

for i, file in enumerate(images, start=1):

    img_path = os.path.join(input_folder, file)
    image = cv2.imread(img_path)

    if image is None:
        continue

    current_image = image
    clone = image.copy()
    boxes = []

    img_h, img_w = image.shape[:2]

    while True:
        cv2.imshow("Annotate", clone)
        key = cv2.waitKey(1) & 0xFF

        # NEXT IMAGE
        if key == ord('n'):
            break

        # RESET BOXES
        if key == ord('r'):
            clone = current_image.copy()
            boxes = []

        # EXIT
        if key == 27:  # ESC
            cv2.destroyAllWindows()
            exit()

        # SAVE
        if key == ord('s'):
            img_id = str(img_index).zfill(3)

            # save image
            save_img_path = os.path.join(images_out, img_id + ".jpg")
            cv2.imwrite(save_img_path, current_image)

            # save label
            label_path = os.path.join(labels_out, img_id + ".txt")

            with open(label_path, "w") as f:
                for (x1, y1, x2, y2) in boxes:
                    xc, yc, bw, bh = convert_yolo(x1, y1, x2, y2, img_w, img_h)
                    class_id = 0  # single class
                    f.write(f"{class_id} {xc:.6f} {yc:.6f} {bw:.6f} {bh:.6f}\n")

            print(f"[SAVED] {img_id}")
            img_index += 1
            break

cv2.destroyAllWindows()