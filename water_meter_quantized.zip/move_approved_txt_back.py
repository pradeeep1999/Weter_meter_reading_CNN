import os
import shutil

# =========================
# Folder Paths
# =========================

# PNG review folder
png_folder = r"D:\Projects\13.Picture_\capture_20260511_145824\2\Wrong_PNG_TFLite"

# TXT folder
txt_folder = r"D:\Projects\13.Picture_\capture_20260511_145824\2\Wrong_TXT_TFLite"

# Final destination folder
destination_folder = r"D:\Projects\13.Picture_\capture_20260511_145824\2"

# =========================
# Move Back Approved Files
# =========================

# Get all remaining PNG files
png_files = [
    f for f in os.listdir(png_folder)
    if f.lower().endswith(".png")
]

moved_count = 0

for png_name in png_files:

    # Example PNG:
    # pred_8_actual_9_image123.png

    # Remove prediction prefix
    txt_name = png_name.split("_", 4)[-1]

    # Convert .png -> .txt
    txt_name = txt_name.replace(".png", ".txt")

    # Full TXT source path
    txt_source = os.path.join(txt_folder, txt_name)

    # Full destination path
    txt_destination = os.path.join(destination_folder, txt_name)

    # Check TXT exists
    if os.path.exists(txt_source):

        # Move TXT back
        shutil.move(txt_source, txt_destination)

        moved_count += 1

        print(f"[✅ MOVED] {txt_name}")

    else:
        print(f"[❌ NOT FOUND] {txt_name}")

# =========================
# Final Result
# =========================

print("\n===================")
print(f"Total moved: {moved_count}")
print("===================")