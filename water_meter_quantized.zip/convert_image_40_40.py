import os
import numpy as np
import cv2

# ==========================================
# Folder Paths
# ==========================================

txt_folder = r"D:\Projects\13.Picture_\03.both_black_and_red_txt\Back_up_file\7"

output_folder = os.path.join(txt_folder, "PNG_40x40")

os.makedirs(output_folder, exist_ok=True)

# ==========================================
# Image Size
# ==========================================

WIDTH = 40
HEIGHT = 40

# RGB565 frame size
FRAME_SIZE = WIDTH * HEIGHT * 2

# ==========================================
# RGB565 -> RGB888 Function
# ==========================================

def rgb565_to_rgb888(frame_bytes):

    raw = np.frombuffer(frame_bytes, dtype=np.uint8)

    low = raw[0::2].astype(np.uint16)
    high = raw[1::2].astype(np.uint16)

    rgb565 = (low << 8) | high

    r = ((rgb565 >> 11) & 0x1F) << 3
    g = ((rgb565 >> 5) & 0x3F) << 2
    b = (rgb565 & 0x1F) << 3

    img = np.stack((r, g, b), axis=-1).astype(np.uint8)

    return img.reshape((HEIGHT, WIDTH, 3))

# ==========================================
# Process All TXT Files
# ==========================================

txt_files = [f for f in os.listdir(txt_folder) if f.endswith(".txt")]

print(f"Found {len(txt_files)} TXT files")

for idx, filename in enumerate(txt_files):

    txt_path = os.path.join(txt_folder, filename)

    try:

        # Read HEX data
        with open(txt_path, "r") as f:
            hex_data = f.read().strip()

        # Convert HEX string -> bytes
        hex_values = hex_data.split(',')

        frame_bytes = bytes(
            int(x, 16) for x in hex_values
        )

        # Check size
        if len(frame_bytes) != FRAME_SIZE:
            print(f"Skipped: {filename} (Wrong size)")
            continue

        # Convert image
        img_rgb = rgb565_to_rgb888(frame_bytes)

        img_bgr = cv2.cvtColor(
            img_rgb,
            cv2.COLOR_RGB2BGR
        )

        # Output PNG filename
        png_name = os.path.splitext(filename)[0] + ".png"

        png_path = os.path.join(
            output_folder,
            png_name
        )

        # Save PNG
        cv2.imwrite(png_path, img_bgr)

        print(f"[{idx+1}] Saved: {png_name}")

    except Exception as e:

        print(f"Error in {filename}: {e}")

print("\nDone!")
print(f"PNG Folder: {output_folder}")