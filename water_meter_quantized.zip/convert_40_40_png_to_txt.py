import os
import cv2
import numpy as np

# ==========================================
# Folder Paths
# ==========================================

png_folder = r"D:\Projects\13.Picture_\03.both_black_and_red_txt\Back_up_file\8\PNG_40x40"

output_folder = os.path.join(png_folder, "TXT_RGB565")

os.makedirs(output_folder, exist_ok=True)

# ==========================================
# Image Size
# ==========================================

WIDTH = 40
HEIGHT = 40

# ==========================================
# RGB888 -> RGB565 Function
# ==========================================

def rgb888_to_rgb565(img_bgr):

    # Convert BGR -> RGB
    img_rgb = cv2.cvtColor(
        img_bgr,
        cv2.COLOR_BGR2RGB
    )

    r = img_rgb[:, :, 0].astype(np.uint16)
    g = img_rgb[:, :, 1].astype(np.uint16)
    b = img_rgb[:, :, 2].astype(np.uint16)

    # Convert RGB888 -> RGB565
    rgb565 = (
        ((r >> 3) << 11) |
        ((g >> 2) << 5)  |
        (b >> 3)
    )

    # Split into LOW and HIGH bytes
    low = (rgb565 >> 8) & 0xFF
    high = rgb565 & 0xFF

    # Interleave bytes
    output = np.empty(rgb565.size * 2, dtype=np.uint8)

    output[0::2] = low.flatten()
    output[1::2] = high.flatten()

    return output

# ==========================================
# Process All PNG Files
# ==========================================

png_files = [
    f for f in os.listdir(png_folder)
    if f.lower().endswith(".png")
]

print(f"Found {len(png_files)} PNG files")

for idx, filename in enumerate(png_files):

    png_path = os.path.join(
        png_folder,
        filename
    )

    try:

        # Read image
        img = cv2.imread(png_path)

        if img is None:
            print(f"Failed to read: {filename}")
            continue

        # Resize if needed
        img = cv2.resize(
            img,
            (WIDTH, HEIGHT)
        )

        # Convert to RGB565 bytes
        rgb565_bytes = rgb888_to_rgb565(img)

        # Convert bytes -> HEX text
        hex_values = [
            f"{b:02X}"
            for b in rgb565_bytes
        ]

        # TXT filename
        txt_name = os.path.splitext(filename)[0] + ".txt"

        txt_path = os.path.join(
            output_folder,
            txt_name
        )

        # Save TXT
        with open(txt_path, "w") as f:
            f.write(",".join(hex_values))

        print(f"[{idx+1}] Saved: {txt_name}")

    except Exception as e:

        print(f"Error in {filename}: {e}")

print("\nDone!")
print(f"TXT Folder: {output_folder}")