import cv2
import os

# =========================
# INPUT & OUTPUT PATHS
# =========================
input_folder = r"D:\Projects\14.Object_detection\04.Real_word_images_by_phone\04.Real_word_images_by_phone"
output_folder = r"D:\Projects\14.Object_detection\04.Real_word_images_by_phone\resized_640"

# Create output folder if not exists
os.makedirs(output_folder, exist_ok=True)

# Target size
target_size = (640, 640)

# =========================
# PROCESS IMAGES
# =========================
for file_name in os.listdir(input_folder):
    file_path = os.path.join(input_folder, file_name)

    # Read image
    img = cv2.imread(file_path)

    # Skip if not an image
    if img is None:
        continue

    # Resize image
    resized = cv2.resize(img, target_size, interpolation=cv2.INTER_AREA)

    # Save output image
    save_path = os.path.join(output_folder, file_name)
    cv2.imwrite(save_path, resized)

print("✅ All images resized to 640x640 successfully!")