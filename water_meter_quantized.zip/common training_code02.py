import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks

# ---------------- CONFIG ----------------
DATA_PATH = r"D:\Projects\13.Picture_\03.both_black_and_red_txt\Back_up_file"
IMG_SIZE = 40 
BATCH_SIZE = 32
# Increased epochs to 150 to help the model learn features despite heavy noise
EPOCHS = 150 
class_names = ['0','1','2','3','4','5','6','7','8','9']

# ---------------- RGB565 TO RGB888 CONVERTER ----------------
def process_rgb565_bytes(hex_list):
    raw_bytes = np.array([int(h, 16) for h in hex_list], dtype=np.uint8)
    low = raw_bytes[0::2].astype(np.uint16)
    high = raw_bytes[1::2].astype(np.uint16)
    rgb565 = (low << 8) | high
    r = ((rgb565 >> 11) & 0x1F) << 3
    g = ((rgb565 >> 5) & 0x3F) << 2
    b = (rgb565 & 0x1F) << 3
    img = np.stack((r, g, b), axis=-1).astype(np.float32)
    return img.reshape((IMG_SIZE, IMG_SIZE, 3))

# ---------------- DATA LOADER ----------------
def load_dataset(base_path, classes):
    images, labels = [], []
    for idx, label in enumerate(classes):
        class_folder = os.path.join(base_path, label)
        if not os.path.exists(class_folder): continue
        files = [f for f in os.listdir(class_folder) if f.endswith(".txt")]
        for file in files:
            file_path = os.path.join(class_folder, file)
            with open(file_path, 'r') as f:
                content = f.read().split(',')
                if len(content) == (IMG_SIZE * IMG_SIZE * 2):
                    images.append(process_rgb565_bytes(content))
                    labels.append(idx)
    return np.array(images), np.array(labels)

X, y = load_dataset(DATA_PATH, class_names)

# Shuffle and Split
indices = np.arange(len(X))
np.random.shuffle(indices)
X, y = X[indices], y[indices]
val_size = int(len(X) * 0.2)
X_train, X_val = X[val_size:], X[:val_size]
y_train, y_val = y[val_size:], y[:val_size]

# shuffle(1000) is used to improve generalization on noisy datasets
train_ds = tf.data.Dataset.from_tensor_slices((X_train, y_train)).shuffle(1000).batch(BATCH_SIZE)
val_ds = tf.data.Dataset.from_tensor_slices((X_val, y_val)).batch(BATCH_SIZE)

# ---------------- TINY MODEL (Target < 30KB) ----------------

core_model = models.Sequential([
    layers.Input(shape=(IMG_SIZE, IMG_SIZE, 3)), 
    layers.Rescaling(1./255),
    
    # Layer 1: Detects basic edges to distinguish thin digits like '1'
    layers.Conv2D(16, (3, 3), activation='relu', padding='same'),
    layers.MaxPooling2D((2, 2)),
    
    # Layer 2: Detects curves and loops to separate '8' from '7'
    layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
    layers.MaxPooling2D((2, 2)),

    # Layer 3: Extra depth to interpret noisy artifacts
    layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
    # BatchNormalization: Critical for handling the static seen in frame_000112_digit_0.png
    layers.BatchNormalization(),
    # GlobalAveragePooling: Keeps TFLite size small by replacing heavy Flatten layers
    layers.GlobalAveragePooling2D(), 

    layers.Dense(32, activation='relu'),
    layers.Dropout(0.2), # Prevents overfitting to noise patterns
    layers.Dense(len(class_names), activation='softmax')
], name="stm32_v2_30kb")

# Minimal rotation (0.02) to prevent confusing '1' and '7'
data_augmentation = models.Sequential([
    layers.RandomTranslation(0.1, 0.1),
    layers.RandomZoom(0.1),
    layers.RandomRotation(0.02),
])

full_model = models.Sequential([data_augmentation, core_model])

# Learning Rate decay helps fine-tune accuracy on difficult digits
lr_schedule = callbacks.LearningRateScheduler(lambda epoch: 1e-3 * 0.95 ** epoch)
stop_early = callbacks.EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)

full_model.compile(optimizer='adam', 
                   loss='sparse_categorical_crossentropy', 
                   metrics=['accuracy'])

# ---------------- TRAIN & SAVE ----------------

full_model.fit(train_ds, validation_data=val_ds, epochs=EPOCHS, callbacks=[stop_early, lr_schedule])

def representative_data_gen():
    for i in range(100):
        data = np.expand_dims(X_train[i], axis=0).astype(np.float32)
        yield [data]

converter = tf.lite.TFLiteConverter.from_keras_model(core_model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]
converter.representative_dataset = representative_data_gen
converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
converter.inference_input_type = tf.int8
converter.inference_output_type = tf.int8

tflite_model = converter.convert()

with open('water_meter_30kb.tflite', 'wb') as f:
    f.write(tflite_model)

print(f"✅ TFLite Size: {len(tflite_model)/1024:.2f} KB")