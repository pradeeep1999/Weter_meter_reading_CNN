import serial
import numpy as np
import tensorflow as tf
import cv2
import time
import logging
import sys

# ==========================================
# CONFIG
# ==========================================

MODEL_PATH = "water_meter_tiny_40kb.tflite"

SERIAL_PORT = 'COM18'
BAUD_RATE = 921600

START_MARKER = b'starting'
END_MARKER   = b'ending'

WIDTH  = 40
HEIGHT = 40

FRAME_SIZE = WIDTH * HEIGHT * 2

class_names = ['0','1','2','3','4','5','6','7','8','9']

# ==========================================
# LOGGING
# ==========================================

logging.basicConfig(
    level=logging.INFO,
    format='[%(levelname)s] %(message)s'
)

# ==========================================
# LOAD TFLITE MODEL
# ==========================================

print("Loading TFLite model...")

interpreter = tf.lite.Interpreter(model_path=MODEL_PATH)
interpreter.allocate_tensors()

input_details  = interpreter.get_input_details()[0]
output_details = interpreter.get_output_details()[0]

is_int8 = input_details['dtype'] == np.int8

print("Model loaded successfully")

# ==========================================
# RGB565 -> RGB888
# ==========================================

def rgb565_to_rgb888(frame_bytes):

    raw = np.frombuffer(frame_bytes, dtype=np.uint8)

    low  = raw[0::2].astype(np.uint16)
    high = raw[1::2].astype(np.uint16)

    rgb565 = (low << 8) | high

    r = ((rgb565 >> 11) & 0x1F) << 3
    g = ((rgb565 >> 5)  & 0x3F) << 2
    b = (rgb565 & 0x1F) << 3

    img = np.stack((r, g, b), axis=-1).astype(np.uint8)

    return img.reshape((HEIGHT, WIDTH, 3))

# ==========================================
# TFLITE PREDICTION
# ==========================================

def predict_tflite_variants(img_rgb):

    best_class = None
    best_conf  = -1

    padded = cv2.copyMakeBorder(
        img_rgb,
        10,10,10,10,
        cv2.BORDER_REPLICATE
    )

    shifts = [-4, 0, 4]

    for shift in shifts:

        crop = padded[
            10+shift:10+shift+40,
            10:10+40
        ]

        input_data = crop.astype(np.float32)

        input_data = np.expand_dims(
            input_data,
            axis=0
        )

        # INT8 MODEL
        if is_int8:

            scale, zero_point = input_details['quantization']

            input_data = (
                input_data / scale + zero_point
            ).astype(np.int8)

        interpreter.set_tensor(
            input_details['index'],
            input_data
        )

        interpreter.invoke()

        output_data = interpreter.get_tensor(
            output_details['index']
        )[0]

        # Dequantize output
        if output_details['dtype'] == np.int8:

            o_scale, o_zero = output_details['quantization']

            output_data = (
                output_data.astype(np.float32) - o_zero
            ) * o_scale

        pred_conf  = np.max(output_data)
        pred_class = np.argmax(output_data)

        if pred_conf > best_conf:

            best_conf  = pred_conf
            best_class = pred_class

    return str(best_class), best_conf

# ==========================================
# MAIN
# ==========================================

def main():

    try:

        ser = serial.Serial(
            SERIAL_PORT,
            BAUD_RATE,
            timeout=1
        )

    except Exception as e:

        print(f"Serial Error: {e}")
        sys.exit(1)

    print(f"Listening on {SERIAL_PORT}")

    buffer = bytearray()

    frame_count = 0

    cv2.namedWindow("Live", cv2.WINDOW_NORMAL)

    cv2.resizeWindow("Live", 400, 400)

    MAX_BUFFER = (
        len(START_MARKER)
        + FRAME_SIZE
        + len(END_MARKER)
    ) * 10

    while True:

        chunk = ser.read(4096)

        if chunk:
            buffer += chunk
        else:
            time.sleep(0.001)
            continue

        # Prevent overflow
        if len(buffer) > MAX_BUFFER:

            print("Buffer overflow")

            buffer.clear()

            continue

        # Find start marker
        start_idx = buffer.find(START_MARKER)

        if start_idx == -1:
            continue

        frame_start = start_idx + len(START_MARKER)

        frame_end = frame_start + FRAME_SIZE

        end_pos = frame_end + len(END_MARKER)

        # Wait full frame
        if len(buffer) < end_pos:
            continue

        frame_data = buffer[frame_start:frame_end]

        received_end_marker = buffer[frame_end:end_pos]

        # ======================================
        # VALID FRAME
        # ======================================

        if received_end_marker == END_MARKER:

            # RGB565 -> RGB888
            img_rgb = rgb565_to_rgb888(frame_data)

            # Predict
            predicted_class, confidence = predict_tflite_variants(img_rgb)

            # RGB -> BGR
            img_bgr = cv2.cvtColor(
                img_rgb,
                cv2.COLOR_RGB2BGR
            )

            # Resize for viewing
            display = cv2.resize(
                img_bgr,
                (400, 400),
                interpolation=cv2.INTER_NEAREST
            )

            # Text
            text = f"Pred: {predicted_class}  Conf: {confidence:.2f}"

            cv2.putText(
                display,
                text,
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0,255,0),
                2
            )

            # Show
            cv2.imshow("Live", display)

            print(
                f"[{frame_count}] "
                f"Prediction: {predicted_class} "
                f"Confidence: {confidence:.2f}"
            )

            frame_count += 1

            # Remove processed bytes
            del buffer[:end_pos]

        else:

            del buffer[:start_idx + 1]

        # ESC Exit
        if cv2.waitKey(1) & 0xFF == 27:

            print("ESC Pressed")

            break

    ser.close()

    cv2.destroyAllWindows()

# ==========================================
# START
# ==========================================

if __name__ == "__main__":
    main()