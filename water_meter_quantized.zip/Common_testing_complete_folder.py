import tensorflow as tf
import numpy as np
import os
import re
import cv2
import shutil

# ===============================
# 1. Load Model
# ===============================
model = tf.keras.models.load_model("water_meter_v2_rgb565.h5")
print("✅ Model Loaded (40x40 RGB)")

# ===============================
# 2. Folder Configuration
# ===============================
desired_folder = r"D:\Projects\13.Picture_\03.both_black_and_red_txt\0"
test_folder = desired_folder

wrong_txt_folder = os.path.join(desired_folder, "Wrong_TXT")
wrong_png_folder = os.path.join(desired_folder, "Wrong_PNG")

class_names = ['0','1','2','3','4','5','6','7','8','9']

# Reset folders
for f in [wrong_txt_folder, wrong_png_folder]:
    if os.path.exists(f):
        shutil.rmtree(f)
    os.makedirs(f)

# ===============================
# 3. RGB565 Conversion
# ===============================
def hex_txt_to_rgb888(file_path):
    with open(file_path, 'r') as f:
        content = f.read().split(',')

    if len(content) != 3200:
        return None

    raw_bytes = np.array([int(h, 16) for h in content], dtype=np.uint8)

    low = raw_bytes[0::2].astype(np.uint16)
    high = raw_bytes[1::2].astype(np.uint16)
    rgb565 = (low << 8) | high

    r = ((rgb565 >> 11) & 0x1F) << 3
    g = ((rgb565 >> 5) & 0x3F) << 2
    b = (rgb565 & 0x1F) << 3

    img = np.stack((r, g, b), axis=-1).astype(np.uint8)
    return img.reshape((40, 40, 3))

# ===============================
# 4. Prediction Function
# ===============================
def predict_best_variant(img_rgb, model):
    best_class = None
    best_conf = -1

    padded = cv2.copyMakeBorder(img_rgb, 10, 10, 10, 10, cv2.BORDER_REPLICATE)
    shifts = [-4, 0, 4]

    for shift in shifts:
        crop = padded[10+shift:10+shift+40, 10:10+40]

        img_array = crop.astype("float32")
        img_array = np.expand_dims(img_array, axis=0)

        predictions = model.predict(img_array, verbose=0)[0]
        pred_conf = float(np.max(predictions))
        pred_class = int(np.argmax(predictions))

        if pred_conf > best_conf:
            best_conf = pred_conf
            best_class = pred_class

    return str(best_class), best_conf

# ===============================
# 5. Process Folder
# ===============================
correct_count = 0
total_count = 0

folder_name = os.path.basename(os.path.normpath(desired_folder))
default_label = folder_name if folder_name in class_names else None

print(f"📂 Testing Folder: {test_folder}")

for filename in os.listdir(test_folder):
    if not filename.lower().endswith('.txt'):
        continue

    file_path = os.path.join(test_folder, filename)

    img_rgb = hex_txt_to_rgb888(file_path)
    if img_rgb is None:
        print(f"⚠️ Skipping {filename}")
        continue

    # label
    match = re.search(r'\((\d)\)', filename)
    if match:
        true_label = match.group(1)
    elif default_label:
        true_label = default_label
    else:
        continue

    # prediction
    predicted_class, confidence = predict_best_variant(img_rgb, model)

    is_correct = (predicted_class == true_label)
    result_text = "RIGHT ✅" if is_correct else "WRONG ❌"

    if is_correct:
        correct_count += 1
    else:
        # =========================
        # WRONG → SPLIT INTO 2 FOLDERS
        # =========================

        # 1. Save PNG
        png_name = f"pred_{predicted_class}_actual_{true_label}_{filename.replace('.txt', '.png')}"
        img_bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
        cv2.imwrite(os.path.join(wrong_png_folder, png_name), img_bgr)

        # 2. Move TXT
        txt_name = f"pred_{predicted_class}_actual_{true_label}_{filename}"
        shutil.move(file_path, os.path.join(wrong_txt_folder, txt_name))

    total_count += 1
    print(f"[{result_text}] {filename} | Pred: {predicted_class} | Actual: {true_label}")

# ===============================
# 6. Final Accuracy
# ===============================
if total_count > 0:
    accuracy = (correct_count / total_count) * 100
    print("\n======================")
    print(f"Accuracy: {accuracy:.2f}%")
    print(f"Total: {total_count} | Correct: {correct_count}")
    print("======================")