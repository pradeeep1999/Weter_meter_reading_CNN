import os
import shutil
import cv2

# Define paths
source_dir = r'D:\Projects\12.STM32_Water reader\vikash'
output_base = r'D:\Projects\12.STM32_Water reader\Sorted_Dataset2'

# Create folders 0-9
for i in range(10):
    os.makedirs(os.path.join(output_base, str(i)), exist_ok=True)

# Loop through images
for filename in os.listdir(source_dir):
    if filename.endswith(('.png', '.jpg', '.jpeg')):
        img_path = os.path.join(source_dir, filename)
        img = cv2.imread(img_path)
        
        # Display the image (resized for better visibility)
        cv2.imshow('Sort Digit - Press 0-9', cv2.resize(img, (200, 200)))
        
        # Wait for user input
        key = cv2.waitKey(0)
        
        # Check if key is 0-9 (ASCII 48-57)
        if 48 <= key <= 57:
            digit = chr(key)
            dest_path = os.path.join(output_base, digit, filename)
            shutil.move(img_path, dest_path)
            print(f"Moved {filename} to folder {digit}")
        elif key == 27: # Press Esc to exit
            break

cv2.destroyAllWindows()