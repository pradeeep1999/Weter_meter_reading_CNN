import numpy as np
import tensorflow as tf
import cv2
import os
import shutil

# ===============================
# 1. Configuration & Paths
# ===============================

MODEL_PATH = "water_meter_30kb.tflite"

# Input folder (1000+ PNG/JPG images)
INPUT_FOLDER = r"C:\Users\vijep\Downloads\processed_digits_result"

# Output base folder
OUTPUT_FOLDER = r"D:\Projects\14.Object_detection\without_crop\capture_20260507_165942"

# Class names
class_names = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

# Create output class folders
for cls in class_names:
    os.makedirs(os.path.join(OUTPUT_FOLDER, cls), exist_ok=True)

# ===============================
# 2. Load TFLite Model
# ===============================

interpreter = tf.lite.Interpreter(model_path=MODEL_PATH)
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()[0]
output_details = interpreter.get_output_details()[0]

is_int8 = input_details['dtype'] == np.int8

# ===============================
# 3. Prediction Function
# ===============================

def predict_tflite(img_rgb):

    # Resize to 40x40
    img_rgb = cv2.resize(img_rgb, (40, 40))

    input_data = img_rgb.astype(np.float32)
    input_data = np.expand_dims(input_data, axis=0)

    # INT8 Quantization
    if is_int8:
        scale, zero_point = input_details['quantization']
        input_data = (input_data / scale + zero_point).astype(np.int8)

    # Run inference
    interpreter.set_tensor(input_details['index'], input_data)
    interpreter.invoke()

    output_data = interpreter.get_tensor(output_details['index'])[0]

    # Dequantize output if INT8
    if output_details['dtype'] == np.int8:
        o_scale, o_zero_point = output_details['quantization']
        output_data = (output_data.astype(np.float32) - o_zero_point) * o_scale

    pred_class = np.argmax(output_data)
    confidence = np.max(output_data)

    return str(pred_class), confidence

# ===============================
# 4. Process Images
# ===============================

print(f"🚀 Processing Images From:\n{INPUT_FOLDER}\n")

supported_formats = ('.png', '.jpg', '.jpeg', '.bmp')

total = 0

for filename in os.listdir(INPUT_FOLDER):

    if not filename.lower().endswith(supported_formats):
        continue

    file_path = os.path.join(INPUT_FOLDER, filename)

    # Read image
    img_bgr = cv2.imread(file_path)

    if img_bgr is None:
        print(f"❌ Cannot Read: {filename}")
        continue

    # Convert BGR → RGB
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

    # Predict
    predicted_class, confidence = predict_tflite(img_rgb)

    # Destination folder
    destination_folder = os.path.join(OUTPUT_FOLDER, predicted_class)

    # Move image
    destination_path = os.path.join(destination_folder, filename)

    shutil.move(file_path, destination_path)

    total += 1

    print(f"[✅] {filename} → Class {predicted_class} ({confidence:.2f})")

# ===============================
# 5. Final Summary
# ===============================

print("\n" + "=" * 40)
print(f"✅ Total Images Processed: {total}")
print("✅ Images Sorted Into 0-9 Folders")
print("=" * 40)