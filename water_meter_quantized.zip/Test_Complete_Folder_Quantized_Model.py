import numpy as np
import tensorflow as tf
import cv2
import os
import shutil
import re

# ===============================
# 1. Configuration & Paths
# ===============================
MODEL_PATH = "water_meter_tiny_40kb.tflite"
# The folder containing your .txt files to test
TEST_FOLDER = r"D:\Projects\13.Picture_\03.both_black_and_red_txt_selected\8"

# Sub-folders for errors
wrong_txt_folder = os.path.join(TEST_FOLDER, "Wrong_TXT_TFLite")
wrong_png_folder = os.path.join(TEST_FOLDER, "Wrong_PNG_TFLite")
class_names = ['0','1','2','3','4','5','6','7','8','9']

# Reset/Create folders
for f in [wrong_txt_folder, wrong_png_folder]:
    if os.path.exists(f):
        shutil.rmtree(f)
    os.makedirs(f)

# ===============================
# 2. Load TFLite Model
# ===============================
interpreter = tf.lite.Interpreter(model_path=MODEL_PATH)
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()[0]
output_details = interpreter.get_output_details()[0]
is_int8 = input_details['dtype'] == np.int8

# ===============================
# 3. Helper Functions
# ===============================
def hex_txt_to_rgb888(file_path):
    with open(file_path, 'r') as f:
        content = f.read().split(',')
    if len(content) != 3200: 
        return None

    raw_bytes = np.array([int(h, 16) for h in content], dtype=np.uint8)
    low = raw_bytes[0::2].astype(np.uint16)
    high = raw_bytes[1::2].astype(np.uint16)
    rgb565 = (low << 8) | high

    r = ((rgb565 >> 11) & 0x1F) << 3
    g = ((rgb565 >> 5) & 0x3F) << 2
    b = (rgb565 & 0x1F) << 3

    img = np.stack((r, g, b), axis=-1).astype(np.uint8)
    return img.reshape((40, 40, 3))

def predict_tflite_variants(img_rgb):
    best_class = None
    best_conf = -1

    padded = cv2.copyMakeBorder(img_rgb, 10, 10, 10, 10, cv2.BORDER_REPLICATE)
    shifts = [-4, 0, 4]

    for shift in shifts:
        crop = padded[10+shift:10+shift+40, 10:10+40]
        input_data = crop.astype(np.float32) 
        input_data = np.expand_dims(input_data, axis=0)

        if is_int8:
            scale, zero_point = input_details['quantization']
            input_data = (input_data / scale + zero_point).astype(np.int8)

        interpreter.set_tensor(input_details['index'], input_data)
        interpreter.invoke()
        output_data = interpreter.get_tensor(output_details['index'])[0]
        
        if output_details['dtype'] == np.int8:
            o_scale, o_zero_point = output_details['quantization']
            output_data = (output_data.astype(np.float32) - o_zero_point) * o_scale

        pred_conf = np.max(output_data)
        pred_class = np.argmax(output_data)

        if pred_conf > best_conf:
            best_conf = pred_conf
            best_class = pred_class

    return str(best_class), best_conf

# ===============================
# 4. Main Processing Loop
# ===============================
correct_count = 0
total_count = 0

# Get folder name to use as default label if regex fails
folder_name = os.path.basename(os.path.normpath(TEST_FOLDER))
default_label = folder_name if folder_name in class_names else None

print(f"🚀 Starting TFLite Inference on: {TEST_FOLDER}")

# Iterate through files in the folder
for filename in os.listdir(TEST_FOLDER):
    if not filename.lower().endswith('.txt'): continue

    file_path = os.path.join(TEST_FOLDER, filename)
    img_rgb = hex_txt_to_rgb888(file_path)
    if img_rgb is None: continue

    # Determine True Label (from filename (x) or folder name)
    match = re.search(r'\((\d)\)', filename)
    true_label = match.group(1) if match else default_label
    if not true_label: continue

    # Predict
    predicted_class, confidence = predict_tflite_variants(img_rgb)
    
    is_correct = (predicted_class == true_label)
    total_count += 1
    
    if is_correct:
        correct_count += 1
        print(f"[✅] {filename} | Pred: {predicted_class} ({confidence:.2f})")
    else:
        print(f"[❌] {filename} | Pred: {predicted_class} | Actual: {true_label} -> MOVING FILE")
        
        # 1. Save PNG for visual review
        img_bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
        png_name = f"pred_{predicted_class}_actual_{true_label}_{filename.replace('.txt', '.png')}"
        cv2.imwrite(os.path.join(wrong_png_folder, png_name), img_bgr)
        
        # 2. MOVE the original TXT to the wrong folder
        # This keeps your TEST_FOLDER clean, leaving only correct ones eventually
        dest_txt_path = os.path.join(wrong_txt_folder, filename)
        shutil.move(file_path, dest_txt_path)

# Final Stats
if total_count > 0:
    print("\n" + "="*30)
    print(f"TFLITE ACCURACY: {(correct_count/total_count)*100:.2f}%")
    print(f"Total: {total_count} | Correct: {correct_count}")
    print("Files moved to 'Wrong_TXT_TFLite' for re-labeling.")
    print("="*30)